import cv2
import mediapipe as mp
import os
import numpy as np

BASE_DIR = os.path.join(os.path.dirname(__file__), "images")
FILES = {
    'normal': 'manzana_normal.jpeg',
    'smile': 'manzana_sonrisa.jpeg',
    'tongue': 'manzana_lengua.jpeg'
}

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

images = {}
for key, filename in FILES.items():
    path = os.path.join(BASE_DIR, filename)
    img = cv2.imread(path)
    if img is None:
        print(f"⚠️ No se pudo cargar {filename}, usando fondo blanco.")
        img = 255 * np.ones((480, 640, 3), dtype=np.uint8)
    images[key] = img

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("No se pudo acceder a la cámara.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ Error al leer la cámara.")
        break

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(frame_rgb)
    expression = 'normal'

    if results.multi_face_landmarks:
        for face_landmarks in results.multi_face_landmarks:
            top_lip = face_landmarks.landmark[13].y
            bottom_lip = face_landmarks.landmark[14].y
            left_mouth = face_landmarks.landmark[61].x
            right_mouth = face_landmarks.landmark[291].x
            left_face = face_landmarks.landmark[234].x
            right_face = face_landmarks.landmark[454].x

            mouth_width = right_mouth - left_mouth
            face_width = right_face - left_face

            if bottom_lip - top_lip > 0.02:
                expression = 'tongue'
            elif mouth_width > 0.35 * face_width:
                expression = 'smile'

    display_img = cv2.resize(images[expression], (frame.shape[1], frame.shape[0]))
    combined = cv2.hconcat([frame, display_img])
    cv2.imshow('Face Expression App', combined)

    if cv2.waitKey(1) & 0xFF == 27:  # ESC para salir
        break

cap.release()
cv2.destroyAllWindows()
